from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet, dobrosaldo
from config import BOT_LINK
from config import BOT_LINK_SUPORTE


@Client.on_message(filters.command(["afiliados", "filiados"]))
@Client.on_callback_query(filters.regex("^afiliados$"))
async def afiliados(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id

    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()

    if isinstance(m, Message):
        refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)

                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"<b>O usuário {mention} se tornou seu referenciado.</b>",
                    )
                except BadRequest:
                    pass

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
               InlineKeyboardButton("📎 COMPARTILHAR", url=f"https://t.me/share/url?url=https://t.me/{c.me.username}?start={m.from_user.id}"),
            ],
        ]
    )
    
    bot_logo, news_channel, support_user = cur.execute(
        "SELECT main_img, channel_user, support_user FROM bot_config WHERE ROWID = 0"
    ).fetchone()
    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    start_message = f"""<a href='https://d6xcmfyh68wv8.cloudfront.net/blog-content/uploads/2020/10/Card-pre-launch_blog-feature-image1.png'>&#8204</a><b>🥇 - Eae {mention} Afim De Ganhar Um Dinheiro? Isso Mesmo Voce Em Que Vai Escolher! Ou Uma CC Ou Um Pix!</b>
    
<b>🔗 - SISTEMA DE AFILIADOS!</b>

<b>📎 - COMO FUNCIONA:</b>

<i>♻️ - Compartilhe Seu Link De Afiliado e Ganhe Saldo No Bot, Como Funciona? E Bem Simples Voce Compartilha Seu Link e a Cada Recarga/Compra Voce Ganha Uma Porcentagem Ou Melhor Voce Saca No Pix!</i>

<b>️📎 - COMPARTILHE SEU LINK AGORA:</b>
<code>{link}</code></b>"""

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text
    save()
    await send(start_message, reply_markup=kb)
