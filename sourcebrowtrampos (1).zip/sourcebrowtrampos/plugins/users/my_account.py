from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save
from utils import get_info_wallet, create_mention, dobrosaldo

import datetime
from typing import Union
import asyncio

@Client.on_callback_query(filters.regex(r"^user_info$"))
async def user_info(c: Client, m: CallbackQuery):
    hora_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    hora_atual_str = hora_atual.strftime('%H:%M:%S')

    data_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    data_atual_str = data_atual.strftime('%d/%m/%Y')
    
    mention = create_mention(m.from_user, with_id=False)
    
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
             [
                 InlineKeyboardButton("💳 HISTÓRICO", callback_data="history"),
                 InlineKeyboardButton("🔁 REEMBOLSO", callback_data="pesquisartroca"),
		         ],
		         [
		             InlineKeyboardButton("⚜️ ALUGAR BOT", callback_data="precos"),
		             InlineKeyboardButton("⚙ SOBRE A STORE", callback_data="dev"),
		      	 ],
		      	 [
				         InlineKeyboardButton("⬅️ Menu Principal", callback_data="start"),
             ],

        ]
    )
    await m.edit_message_text(
        f"""<a href='https://i.ibb.co/QdSMNKH/IMG-20240719-025710-810.jpg'>&#8204</a><b>👤 Suas Informações:</b>

<b>🆔 - Meu ID: {m.from_user.id}</b>
<b>👑 - User: {mention}</b>
<b>🥇 - Nome: {m.from_user.first_name}</b>

<b>⬇️ - Confira Abaixo:</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^dev$"))
async def dev(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
			        	InlineKeyboardButton("⚜️ Alugar Bot", url="https://t.me/BrowTrampos"),
	              InlineKeyboardButton("⚜️ Atualizações", url="https://t.me/RepositorioDoBrow"),
		      	],
		      	[
                 InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )
    await m.edit_message_text(
        f"""<a href='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZwK3NiWuYaWJO0iqE_cjIzX7fTBWcGRlhgQ&usqp=CAU'>&#8204</a><b>👑 - Feito Em Python Teve Varias Versões e Muitos Desenvolvimentos Foram Feitas! Aqui Vão Algumas Delas:</b>

<b>• Vendas Aprimoradas Com Um Refresh Feita Em Todos Os Arquivos Deixando o Bot Mais Leve!</b>

<b>• Configurações Aprimoradas Tendo Como Consequencia Uma Administração Melhor Do Nosso Bot!</b>

<b>• Source Totalmente Refeita Do Absolutamente 0 Com Toda a Parte Da Programação Feita Por: @BrowTrampos!</b>

<b>• Opções De Ativação De Botões Pelo Painel De Administração Podendo Ter Uma Relação Melhor Com Vendas!</b>

<b>• Source vazada por mim: @BrowTrampos! Por favor, não venda essa source! Se você comprou, lamento mais você tomou um lotter!</b>

<i>● Um Oferecimento: @BrowTrampos ● @BrowShopBot ● @SintoniaEvos ● @RepositorioDoBrow ● @GrupoDoBrow</i>""",
        reply_markup=kb,
    )  

@Client.on_callback_query(filters.regex(r"^history$"))
async def history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
        [
             InlineKeyboardButton("🔁 Historico de CCs", callback_data="buy_history_cc"),
    		],
    		[
		         InlineKeyboardButton("🔁 Histórico De Fulls", callback_data="buy_history_full"),
        ],
        [
             InlineKeyboardButton("◀️ Menu Principal", callback_data="user_info"),
        ],
      ]
    )
    await m.edit_message_text(
        f"""<a href='https://d6xcmfyh68wv8.cloudfront.net/blog-content/uploads/2020/10/Card-pre-launch_blog-feature-image1.png'>&#8204</a>♻️ - Selecione Qual Historico de Compras Você Deseja Ver:</b>""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^buy_history_cc$"))
async def buy_history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="history"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>⚠️ Não há nenhuma compra nos Registros.</b>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""<b>💳 Histórico de compras</b>
<i>- Histórico das ultimas compras.</i>
<b>CC | MES | ANO | CVV</b>

{cards_txt}""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex(r"^buy_history_full$"))
async def buy_history_full(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="history"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold_full WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>⚠️ Não há nenhuma compra nos Registros.</b>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card_full]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards_full])

    await m.edit_message_text(
        f"""<b>💳 Histórico de compras Full</b>
<i>- Histórico das ultimas compras.</i>
<b>CC | MES | ANO | CVV | NOME | CPF</b>

{cards_txt}""",
        reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^swap$"))
async def swap_points(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )

    user_id = m.from_user.id
    balance, diamonds = cur.execute(
        "SELECT balance, balance_diamonds FROM users WHERE id=?", [user_id]
    ).fetchone()

    if diamonds >= 1200:
        add_saldo = round((diamonds / 100), 100)
        new_balance = round((balance + add_saldo), 10)

        txt = f"⚜️ Seus <b>{diamonds}</b> pontos foram convertidos em R$ <b>{add_saldo}</b> de saldo."

        cur.execute(
            "UPDATE users SET balance = ?, balance_diamonds=?  WHERE id = ?",
            [new_balance, 0, user_id],
        )
        return await m.edit_message_text(txt, reply_markup=kb)

    await m.answer(
        "⚠️ Você não tem pontos suficientes para realizar a troca. O mínimo é 100 pontos.",
        show_alert=True,
    )


@Client.on_callback_query(filters.regex(r"^swap_info$"))
async def swap_info(c: Client, m: CallbackQuery):
    await m.message.delete()

    cpf = await m.message.ask(
        "<b>👤 CPF da lara (válido) da lara que irá pagar</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )
    name = await m.message.ask(
        "<b>👤 Nome completo do pagador</b>", reply_markup=ForceReply(), timeout=120
    )
    email = await m.message.ask(
        "<b>📧 E-mail</b>", reply_markup=ForceReply(), timeout=120
    )
    cpf, name, email = cpf.text, name.text, email.text
    cur.execute(
        "UPDATE users SET cpf = ?, name = ?, email = ?  WHERE id = ?",
        [cpf, name, email, m.from_user.id],
    )
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("⬅️ Menu Principal", callback_data="start"),
            ]
        ]
    )
    await m.message.reply_text(
        "<b>✅️ Seus dados foram alterados com sucesso.</b>", reply_markup=kb
    )



