from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet, dobrosaldo
from config import BOT_LINK
from config import BOT_LINK_SUPORTE

@Client.on_callback_query(filters.regex(r"^termos$"))
async def termos(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
      
            [
				InlineKeyboardButton("✅️ Concordar", callback_data="shop"),
				InlineKeyboardButton("❌️ Discorda", url="https://t.me/BrowTrampos"),
            ],
        ]
    )
    mention = create_mention(m.from_user, with_id=False)
    await m.edit_message_text(
        f"""<b><a href='https://d6xcmfyh68wv8.cloudfront.net/blog-content/uploads/2020/10/Card-pre-launch_blog-feature-image1.png'>&#8204</a><b>⚠️ - Ei {mention} Fique Ligado Nos Termos, Para Não Haver Dejavencias No Meu PV</b>

<b>♻️ - Trocas Feitas Apenas Pelo Bot, Não Me Responsabilizo Por Mau Uso De Quaisquer Material, Compre Apenas Se Você Estiver De Acordo Com Os Termos De Uso, Estamos Aqui Para Oferecer O Melhor Atendimento a Você, Nosso Cliente. Obrigado!</b>

<b>💳 CCS AUXILIARES:</b>
<b>❌️ NÃO GARANTO SALDO!</b>
<b>❌️ NÃO GARANTO SUA APROVAÇÃO!</b>
<b>⚠️ ATE 15 MINUTOS PARA REALIZAR A TROCA!</b>

<b>💳 CCS FULLS:</b>
<b>✅️ GARANTO DEBITO DE ATE 500 NAS FULLS</b>
<b>⚠️ ATE 20 MINUTOS PARA REALIZAR A TROCA!</b>

<b>Respeite As Regras Para Ter Um Ambiente Limpo e Seguro, Se Caso Não Aceite Os Termos Nos Avise No PV!</b>""",
        reply_markup=kb,
    )