from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet

GROUP_ID = -1002247631540 #id do teu canal, vai obrigar a entrada pra poder usar o bot

async def check_user_in_group(c: Client, user_id: int):
    try:
        await c.get_chat_member(GROUP_ID, user_id)
        return True, None  
    except Exception as e:
        if "USER_NOT_PARTICIPANT" in str(e):
            message = "<b>Para acessar esse bot é obrigatório que se inscreva no canal clicando no botão abaixo para poder começar a usar o Bot!</b>"
            return False, message
        else:
            print("Error checking user in group: ", e)
            return False, '<b>Ocorreu um erro ao verificar sua participação no grupo. Tente novamente mais tarde.</b>'

kb = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Registre-se", url="t.me/BrowStoreBot"),
        ],
    ]
)


@Client.on_message(filters.command(["start", "menu"]))
@Client.on_callback_query(filters.regex("^start$"))
async def start(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id
    user_name = m.from_user.first_name

    is_in_group, message = await check_user_in_group(c, user_id)
    if not is_in_group:
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[[InlineKeyboardButton("Entre no Canal", url="https://t.me/RepositorioDoBrow")]]
        )
        await m.reply_text(message, reply_markup=keyboard)
        return
      
    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()

    if isinstance(m, Message):
        refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)

                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"🎁 <b>Parabéns, o usuário {mention} se vinculou com seu link de afiliado e você receberá uma porcentagem do que o mesmo adicionar no nosso bot.</b>",
                    )
                except BadRequest:
                    pass

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("💳 COMPRAR", callback_data="shop"),
            ],
            [
                InlineKeyboardButton("💸 ADD SALDO", callback_data="add_saldo"), 
                InlineKeyboardButton("👤 PERFIL", callback_data="user_info"),
            ],
            [
                InlineKeyboardButton("♻️ TERMOS", callback_data="termos"),
                InlineKeyboardButton("️🥇 SUPORTE", url="https://t.me/BrowTrampos"),
            ],
        ]
    )
    mention = create_mention(m.from_user, with_id=False)
    bot_logo, news_channel, support_user = cur.execute(
        "SELECT main_img, channel_user, support_user FROM bot_config WHERE ROWID = 0"
    ).fetchone()

    start_message = f"""‌<a href='{bot_logo}'>&#8204</a><b>💳 Olá, {mention} Seja Bem Vindo a Store De Vendas Do @BrowTrampos</b>

<b>⚠️ - Por Favor Leia Os Termos De Troca Em: 👤 Meu Perfil - ♻️ Termos!</b>
<b>👑 - Duvidas/Perguntas Contate o Dono Do Bot: @BrowTrampos</b>

{get_info_wallet(m.from_user.id)}"""
    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text
    save()
    await send(start_message, reply_markup=kb)
