import asyncio

from pyrogram import Client, filters
from pyrogram.types import (
   CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InputTextMessageContent,
)

@Client.on_callback_query(filters.regex(r"^pesquisartroca"))
async def pesquisartroca(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[            
            [
                InlineKeyboardButton("⏰️ Trocar Fulls", callback_data="exchangefull"),
            ],
            [
                InlineKeyboardButton("⏰️ Trocar CC", callback_data="exchange"),
            ],
            [
                 InlineKeyboardButton("⬅️ Menu Principal", callback_data="user_info"),
            ],
        ]
    )
    await m.edit_message_text(
        f"""<a href='https://d6xcmfyh68wv8.cloudfront.net/blog-content/uploads/2020/10/Card-pre-launch_blog-feature-image1.png'>&#8204</a><b>🔁 | Filtros de Trocas</b>

<i>- Escolha um tipo de troca para começar as trocas no bot!</i>""",
        reply_markup=kb,
	)